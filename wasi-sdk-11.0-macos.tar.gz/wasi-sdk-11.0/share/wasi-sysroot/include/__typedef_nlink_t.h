#ifndef __wasilibc___typedef_nlink_t_h
#define __wasilibc___typedef_nlink_t_h

/* Define these as 64-bit unsigned integers to support billions of links. */
typedef unsigned long long nlink_t;

#endif
