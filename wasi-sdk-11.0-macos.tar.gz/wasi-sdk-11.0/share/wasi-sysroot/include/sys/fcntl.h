#warning redirecting incorrect #include <sys/fcntl.h> to <fcntl.h>
#include <fcntl.h>
